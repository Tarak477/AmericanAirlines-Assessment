package com.aa.act.interview.org;

import java.util.Optional;

public abstract class Organization {

	private Position root;
	private  static int counter=1;
	
	private synchronized  static int getCounter() {
		return counter++;
	}

	public Organization() {
		root = createOrganization();
	}

	protected abstract Position createOrganization();

	/**
	 * hire the given person as an employee in the position that has that title
	 * 
	 * @param person
	 * @param title
	 * @return the newly filled position or empty if no position has that title
	 */
	public Optional<Position> hire(Name person, String title) {
		// your code here
		Optional<Position>  optPosition = positionExistsWithTitle(title, root);
		if(optPosition.isEmpty()) {
			return optPosition;
		}
		
		
		int newId = this.getCounter();
		
		Employee emp=new Employee(newId, person);
		
		optPosition.get().setEmployee(Optional.of(emp));
		
		return optPosition;
	}

	private Optional<Position> positionExistsWithTitle(String title, Position base) {
		if (title.equalsIgnoreCase(base.getTitle())) {
			return Optional.of(base);
		}

		for (Position curr : base.getDirectReports()) {
			Optional<Position> res = positionExistsWithTitle(title, curr);
			if (res.isPresent() == false)
				continue;

			if (res.get().isFilled())
				continue;
			return res;
		}

		return Optional.empty();
	}

	@Override
	public String toString() {
		return printOrganization(root, "");
	}

	private String printOrganization(Position pos, String prefix) {
		StringBuffer sb = new StringBuffer(prefix + "+-" + pos.toString() + "\n");
		for (Position p : pos.getDirectReports()) {
			sb.append(printOrganization(p, prefix + "\t"));
		}
		return sb.toString();
	}
}
